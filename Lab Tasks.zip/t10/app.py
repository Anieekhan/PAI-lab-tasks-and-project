from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot():
    user = request.json["message"].lower()

    if "hello" in user or "hi" in user:
        reply = "Hello! Welcome to Library Assistant."

    elif "timing" in user or "hours" in user:
        reply = "Library is open from 8 AM to 8 PM."

    elif "book" in user:
        reply = "Please tell me book name to search."

    elif "due date" in user:
        reply = "Your due date is after 14 days of issue."

    elif "fine" in user:
        reply = "Fine is Rs.20 per late day."

    elif "membership" in user:
        reply = "Membership fee is Rs.500 yearly."

    else:
        reply = "Sorry, I didn't understand."

    return jsonify({"response": reply})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)