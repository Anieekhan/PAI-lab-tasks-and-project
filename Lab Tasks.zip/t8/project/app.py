from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

# Home page (frontend)
@app.route('/')
def home():
    return render_template('index.html')

# API route (backend)
@app.route('/get_joke')
def get_joke():
    url = "https://official-joke-api.appspot.com/random_joke"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        return jsonify({
            "setup": data["setup"],
            "punchline": data["punchline"]
        })
    else:
        return jsonify({"error": "Failed"}), 500


if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True, port=5002)