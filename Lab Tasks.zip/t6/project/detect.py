import cv2
import numpy as np

def detect_animals(image_path):
    net = cv2.dnn.readNet("yolov3.weights", "yolov3.cfg")

    with open("coco.names", "r") as f:
        classes = f.read().splitlines()

    img = cv2.imread(image_path)
    height, width, _ = img.shape

    blob = cv2.dnn.blobFromImage(img, 1/255, (416, 416), swapRB=True)
    net.setInput(blob)

    outputs = net.forward(net.getUnconnectedOutLayersNames())

    count = 0

    for output in outputs:
        for detection in output:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]

            if confidence > 0.5:
                label = classes[class_id]

                # Only animals
                if label in ["cow", "dog", "horse", "sheep"]:
                    count += 1

                    w = int(detection[2] * width)
                    h = int(detection[3] * height)
                    x = int(detection[0] * width - w / 2)
                    y = int(detection[1] * height - h / 2)

                    cv2.rectangle(img, (x, y), (x+w, y+h), (0,255,0), 2)
                    cv2.putText(img, label, (x, y-10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)

    cv2.imwrite("static/output.jpg", img)

    if count >= 3:
        return "Herd Detected", count
    else:
        return "No Herd", count