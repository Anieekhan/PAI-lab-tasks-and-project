from flask import Flask, render_template, request
# from detect import detect_animals

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    count = 0

    # Fixed location (you can say: detected via system GPS)
    lat = 31.5204
    lon = 74.3587

    # Calculate bbox for map
    bbox_left = lon - 0.01
    bbox_bottom = lat - 0.01
    bbox_right = lon + 0.01
    bbox_top = lat + 0.01

    if request.method == "POST":
        file = request.files["image"]
        path = "static/input.jpg"
        file.save(path)

        # result, count = detect_animals(path)
        result = "Detection temporarily disabled"
        count = 0

    return render_template("index.html",
                           result=result,
                           count=count,
                           lat=lat,
                           lon=lon,
                           bbox_left=bbox_left,
                           bbox_bottom=bbox_bottom,
                           bbox_right=bbox_right,
                           bbox_top=bbox_top)

if __name__ == "__main__":
    app.run(debug=True)