from flask import Flask, jsonify
import requests

# Create Flask app
app = Flask(__name__)

# Home route (optional)
@app.route('/')
def home():
    return "Welcome to Random Joke API 😄"

# Route to get single random joke
@app.route('/joke', methods=['GET'])
def get_joke():
    url = "https://official-joke-api.appspot.com/random_joke"
    
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()
        
        return jsonify({
            "setup": data["setup"],
            "punchline": data["punchline"]
        })
    else:
        return jsonify({"error": "Failed to fetch joke"}), 500


# BONUS: Get multiple jokes
@app.route('/jokes/<int:num>', methods=['GET'])
def get_multiple_jokes(num):
    jokes = []
    
    for _ in range(num):
        url = "https://official-joke-api.appspot.com/random_joke"
        response = requests.get(url)
        
        if response.status_code == 200:
            data = response.json()
            jokes.append({
                "setup": data["setup"],
                "punchline": data["punchline"]
            })
    
    return jsonify(jokes)

# Route for /jokes (defaults to 1 joke)
@app.route('/jokes', methods=['GET'])
def get_jokes():
    return get_joke()


# Run app
if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True, port=5001)