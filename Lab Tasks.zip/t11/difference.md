# Lab 11 – Task 1

## Difference Between Given Concepts

---

## 1. LangChain

LangChain ek framework hai jo LLM based applications banane ke liye use hota hai. Is se chatbots, PDF Q&A systems, memory bots aur AI agents banaye ja sakte hain.

### Use:

* Chatbots
* AI Agents
* RAG Systems

### Example:

ChatGPT + PDF Search App

---

## 2. LLMs (Large Language Models)

LLMs large AI language models hote hain jo huge text data par trained hote hain. Yeh human-like text generate karte hain.

### Examples:

* GPT-4
* Gemini
* LLaMA

### Use:

* Text Generation
* Translation
* Coding
* Chatbots

---

## 3. RAG (Retrieval-Augmented Generation)

RAG ka matlab hai:

```python id="x6gx7j"
LLM + Search + External Data
```

Isme AI pehle documents/database se information retrieve karta hai phir answer deta hai.

### Use:

* PDF Chatbot
* Company FAQ Bot
* Smart Search Bot

---

## 4. FAISS (Facebook AI Similarity Search)

FAISS ek library hai jo vectors ko fast search karti hai.

Yeh similar documents ya similar questions find karne ke liye use hoti hai.

### Use:

* Semantic Search
* Fast Retrieval
* Vector Search

---

## 5. Vector

Vector numbers ki list hoti hai jo words ya sentences ko represent karti hai.

### Example:

```python id="0n33gv"
"apple" = [0.21, -0.44, 0.88, 0.12]
```

Yeh meaning ko represent karta hai.

---

## 6. VectorDB

Vector Database vectors ko store karta hai aur quickly search karta hai.

### Examples:

* Pinecone
* ChromaDB
* Weaviate
* Qdrant

### Use:

* Chatbots
* Search Engines
* Recommendation Systems

---

## 7. Generative AI (GenAI)

GenAI aisi AI hai jo new content create karti hai.

### Create Kar Sakti Hai:

* Text
* Images
* Music
* Code
* Video

### Examples:

* ChatGPT
* DALL·E
* Midjourney

---

## 8. GANs (Generative Adversarial Networks)

GAN ek AI model hai jisme 2 neural networks hotay hain:

1. Generator → Fake data banata hai
2. Discriminator → Check karta hai real ya fake

Dono compete karte hain.

### Use:

* Face Generation
* Deepfake
* Image Creation

---

# Final Difference Table

| Concept   | Meaning               | Use                 |
| --------- | --------------------- | ------------------- |
| LangChain | LLM App Framework     | Chatbots            |
| LLMs      | Language AI Models    | Text Generation     |
| RAG       | LLM + Search          | Smart Answers       |
| FAISS     | Fast Vector Search    | Similarity Search   |
| Vector    | Number Representation | AI Meaning          |
| VectorDB  | Vector Storage DB     | Retrieval           |
| GenAI     | Content Creating AI   | Text/Image          |
| GANs      | Two Network Generator | Fake Image Creation |

---
