from flask import Flask, render_template, request, jsonify
import os
from utils import analyze_resume, extract_text_from_pdf

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    text = ""

    
    if "resume" in request.files:
        file = request.files["resume"]
        if file.filename != "":
            path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(path)
            text = extract_text_from_pdf(path)

   
    if not text:
        text = request.form.get("resume_text")

    if not text:
        return jsonify({"error": "No resume provided"})

    result = analyze_resume(text)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)