import re
import PyPDF2


SKILLS_DB = [
    "python", "java", "c++", "machine learning", "data science",
    "sql", "html", "css", "javascript", "flask", "django"
]

def extract_text_from_pdf(file_path):
    text = ""
    with open(file_path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            text += page.extract_text()
    return text


def analyze_resume(text):
    text_lower = text.lower()

    
    found_skills = [skill for skill in SKILLS_DB if skill in text_lower]

  
    experience = re.findall(r'\d+\s+years', text_lower)

    
    email = re.findall(r'\S+@\S+', text)

   
    score = len(found_skills) * 10
    if len(text) > 500:
        score += 20

    
    suggestions = []
    if len(found_skills) < 5:
        suggestions.append("Add more relevant skills.")
    if not experience:
        suggestions.append("Mention your experience clearly.")
    if len(text) < 300:
        suggestions.append("Resume is too short.")

    return {
        "skills": found_skills,
        "experience": experience,
        "email": email,
        "score": score,
        "suggestions": suggestions
    }