function analyzeResume() {
    let formData = new FormData();

    let fileInput = document.getElementById("fileInput").files[0];
    let text = document.getElementById("resumeText").value;

    if (fileInput) {
        formData.append("resume", fileInput);
    } else {
        formData.append("resume_text", text);
    }

    fetch("/analyze", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        let resultDiv = document.getElementById("result");

        if (data.error) {
            resultDiv.innerHTML = data.error;
            return;
        }

        resultDiv.innerHTML = `
            <h3>Score: ${data.score}</h3>
            <p><b>Skills:</b> ${data.skills.join(", ")}</p>
            <p><b>Experience:</b> ${data.experience.join(", ")}</p>
            <p><b>Email:</b> ${data.email}</p>
            <p><b>Suggestions:</b> ${data.suggestions.join("<br>")}</p>
        `;
    });
}